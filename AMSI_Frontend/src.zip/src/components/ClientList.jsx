import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getClifors } from '../services/api';
import ToastStack, { useToast } from './ToastStack.jsx';
import '../styles/clientList.css';

function ClientList() {
	const navigate = useNavigate();
	const { toasts, mostrarToast, removerToast } = useToast();
	const [clifors, setClifors] = useState([]);
	const [loading, setLoading] = useState(true);
	const [busca, setBusca] = useState('');
	const [filtroTipo, setFiltroTipo] = useState('');
	const [filtroAtivo, setFiltroAtivo] = useState('');

	useEffect(() => {
		carregar();
	}, []);

	async function carregar() {
		setLoading(true);
		try {
			const data = await getClifors();
			setClifors(data);
		} catch (err) {
			mostrarToast(err.message || 'Erro ao carregar clientes/fornecedores', 'erro');
		} finally {
			setLoading(false);
		}
	}

	const filtrados = clifors.filter((c) => {
		const buscaOk = !busca || c.nome.toLowerCase().includes(busca.toLowerCase());
		const tipoOk = !filtroTipo || c.tipo_clifor === filtroTipo;
		const ativoOk = filtroAtivo === '' || String(c.ativo) === filtroAtivo;
		return buscaOk && tipoOk && ativoOk;
	});

	const tipoLabel = (t) => (t === 'C' ? 'Cliente' : t === 'F' ? 'Fornecedor' : 'Ambos');

	return (
		<div className="cl-container">
			<ToastStack toasts={toasts} onRemover={removerToast} />

			<div className="cl-header">
				<h4 className="cl-title">Clientes / Fornecedores</h4>
				<button className="cl-btn-novo" onClick={() => navigate('/cliente_fornecedor/novo')}>
					+ Novo
				</button>
			</div>

			<div className="cl-filtros">
				<input
					className="cl-busca"
					placeholder="Buscar por nome..."
					value={busca}
					onChange={(e) => setBusca(e.target.value)}
				/>
				<select
					className="cl-select"
					value={filtroTipo}
					onChange={(e) => setFiltroTipo(e.target.value)}
				>
					<option value="">Todos os tipos</option>
					<option value="C">Cliente</option>
					<option value="F">Fornecedor</option>
					<option value="A">Ambos</option>
				</select>
				<select
					className="cl-select"
					value={filtroAtivo}
					onChange={(e) => setFiltroAtivo(e.target.value)}
				>
					<option value="">Todos</option>
					<option value="true">Ativos</option>
					<option value="false">Inativos</option>
				</select>
			</div>

			{loading ? (
				<p className="cl-loading">Carregando...</p>
			) : filtrados.length === 0 ? (
				<p className="cl-vazio">Nenhum resultado encontrado.</p>
			) : (
				<div className="cl-table-wrapper">
					<table className="cl-table">
						<thead>
							<tr>
								<th>Nome</th>
								<th>Tipo</th>
								<th>CPF / CNPJ</th>
								<th>Status</th>
								<th>Inadimplente</th>
								<th>Ações</th>
							</tr>
						</thead>
						<tbody>
							{filtrados.map((c) => (
								<tr key={c.id_clifor}>
									<td>{c.nome}</td>
									<td>{tipoLabel(c.tipo_clifor)}</td>
									<td className="cl-doc">{c.cpf_cnpj}</td>
									<td>
										<span
											className={`cl-badge ${c.ativo ? 'cl-badge--ativo' : 'cl-badge--inativo'}`}
										>
											{c.ativo ? 'Ativo' : 'Inativo'}
										</span>
									</td>
									<td>
										<span
											className={`cl-badge ${c.inadimplente ? 'cl-badge--inadimplente' : 'cl-badge--ok'}`}
										>
											{c.inadimplente ? 'Sim' : 'Não'}
										</span>
									</td>
									<td>
										<button
											className="cl-btn-editar"
											onClick={() => navigate(`/cliente_fornecedor/${c.id_clifor}/editar`)}
										>
											<i className="bi bi-pencil"></i> Editar
										</button>
									</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			)}
		</div>
	);
}

export default ClientList;
